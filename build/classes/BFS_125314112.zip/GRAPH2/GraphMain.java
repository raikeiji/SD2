package GRAPH2;

/*
Nama : ENGELBERTUS VIONE
NIM  : 125314112 
*/
public class GraphMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("DFS");
        Graph g = new Graph();
        g.addVertex('A');
        g.addVertex('B');
        g.addVertex('C');
        g.addVertex('D');
        g.addVertex('E');
        g.addVertex('F');

        g.addEdge('A', 'B', 10);
        g.addEdge('A', 'F', 5);
        g.addEdge('B', 'C', 9);
        g.addEdge('B', 'E', 4);
        g.addEdge('B', 'F', 2);
        g.addEdge('C', 'F', 8);
        g.addEdge('E', 'F', 11);
        g.addEdge('C', 'E', 7);
        g.addEdge('E', 'D', 3);
        g.addEdge('C', 'D', 6);

        g.show();
//        System.out.println("DFS");
//        g.dfs();
        System.out.println("BFS");
        g.BFS();
    }
}
